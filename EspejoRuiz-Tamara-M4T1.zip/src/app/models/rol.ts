export  interface Rol{
    id?:number;
    name:string;
    isDeleted?:number;
}